import pandas as pd

df = pd.read_csv('sample_responses.csv', delimiter=',')
