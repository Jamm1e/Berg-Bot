

info_track = {'First name': 0,"Last Name": 1, "Birth Date": 2, "Email": 3, "Address": 4, "Entry Term": 5, "Major": 6, "GPA": 7}

for k,v in info_track.items():
    print(f'enter {k} code{v}')
    


